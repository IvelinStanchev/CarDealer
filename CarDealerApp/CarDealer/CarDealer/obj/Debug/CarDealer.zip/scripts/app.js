/// <reference path="../kendo/js/jquery.min.js" />

(function () {
    document.addEventListener("deviceready", function () {
        document.addEventListener("pause", onPause, false);

        function onPause() {
            alert("Your program has been in pause for a while. Click OK to resume");
        }

        window.files = [];

        var app = new kendo.mobile.Application(document.body, {
            skin: "flat",
            initial: "home-view",
            transition: "slide"
        });

        $("#cars").on("click", "div", function ($e) {
            console.log($e.currentTarget.children[1].lastChild.id);
            app.navigate("views/singleAdView.html");

            $(".model-container").append("<p>Test</p>");
        });

        window.everlive = new Everlive("84Kc0v5WmmEQxXDe");

        //navigator.connection.type = Connection.NONE;

        var hasConnection = window.CheckForConnection();

        if (!hasConnection) {
            alert("No internet connection!");

            var interval = setInterval(function () {
                hasConnection = window.CheckForConnection();

                if (hasConnection) {
                    alert("You are now connected to internet.");
                    clearInterval(interval);
                    window.LoadPhotos();
                }
            }, 1500);
        }
        else {
            window.LoadPhotos();
        }

        //function loadPhotos() {
        //    var hasConnection = checkForConnection();
        //    if (!hasConnection) {
        //        navigator.notification.alert("No internet connection. Please, provide connection and try again.");
        //    }

        //    window.files = [];
        //    window.everlive.data('CarDealer').get()
        //        .then(function (data) {
        //            data.result.forEach(function (file) {
        //                $.ajax({
        //                    type: "GET",
        //                    url: 'http://api.everlive.com/v1/84Kc0v5WmmEQxXDe/Files/' + file.Pic,
        //                    //headers: { "Authorization" : "Bearer your-access-token-here" },
        //                    contentType: "application/json",
        //                }).then(function (picData) {
        //                    files.push({
        //                        'brand': file.Brand,
        //                        'model': file.Model,
        //                        'fuelType': file.FuelType,
        //                        'year': file.Year,
        //                        'kilometers': file.Kilometers,
        //                        'price': file.Price,
        //                        'description': file.Description,
        //                        'name': file.Name,
        //                        'phoneNumber': file.PhoneNumber,
        //                        'imageUrl': picData.Result.Uri
        //                    });
        //                })
        //                    .then(function () {
        //                        $("#cars").kendoMobileListView({
        //                            dataSource: files,
        //                            template:
        //                                "<div id=\"eachItem\">" +
        //                                        "<img src='#= data.imageUrl #'>" +
        //                                        "<div id=\"eachItemContainer\">" +
        //                                                "<div id=\"brand\">Brand: #= data.brand #</div>" +
        //                                                "<div id=\"model\">Model: #= data.model #</div>" +
        //                                                "<div id=\"kilometers\">Kilometers: #= data.kilometers #</div>" +
        //                                                "<div id=\"price\">Price: #= data.price #</div>" +
        //                                        "</div>" +
        //                                "</div>"
        //                        });
        //                    });
        //            });
        //        });
        //}
        //loadPhotos();

        //console.log(window);

        //window.LoadPhotos();
    });
}());