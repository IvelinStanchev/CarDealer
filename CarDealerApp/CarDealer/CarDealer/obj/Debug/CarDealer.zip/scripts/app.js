/// <reference path="../kendo/js/jquery.min.js" />

(function () {
    document.addEventListener("deviceready", function () {
        window.files = [];

        var app = new kendo.mobile.Application(document.body, {
            skin: "flat",
            initial: "home-view",
            //transition: "slide"
        });

        $("#cars").on("click", "div", function ($e) {
            console.log($e.currentTarget.children[0].src);
            app.navigate("views/singleAdView.html");

            $(".model-container").append("<p>Test</p>");
        });

        window.everlive = new Everlive("84Kc0v5WmmEQxXDe");

        //window.listView = kendo.observable({
        //    addImage: function () {
                
        //    }
        //});

        var app = new kendo.mobile.Application(document.body, {
            skin: "flat"
        });

        function checkForConnection() {
            var networkState = navigator.connection.type;

            if (networkState == Connection.NONE) {
                return false;
            }

            return true;
        }

        function loadNewViewFunction(){
            console.log("pesho");
        }

        function loadPhotos() {
            var hasConnection = checkForConnection();
            if (!hasConnection) {
                navigator.notification.alert("No internet connection. Please, provide connection and try again.");
            }

            window.everlive.data('CarDealer').get()
                .then(function (data) {
                    data.result.forEach(function (file) {
                        $.ajax({
                            type: "GET",
                            url: 'http://api.everlive.com/v1/84Kc0v5WmmEQxXDe/Files/' + file.Pic,
                            //headers: { "Authorization" : "Bearer your-access-token-here" },
                            contentType: "application/json",
                        }).then(function (picData) {
                            files.push({
                                'brand': file.Brand,
                                'model': file.Model,
                                'fuelType': file.FuelType,
                                'year': file.Year,
                                'kilometers': file.Kilometers,
                                'description': file.Description,
                                'imageUrl': picData.Result.Uri
                            });
                        })
                            .then(function () {
                                $("#cars").kendoMobileListView({
                                    dataSource: files,
                                    template:
                                        "<div id=\"eachItem\">" +
                                            "<img src='#= data.imageUrl #'>" +
                                            "<div id=\"data\">Model: #= data.model #</div>" +
                                        "</div>"
                                });
                            });
                    });
                });
        }
        loadPhotos();
    });
}());