(function () {
    window.LoadPhotos = function () {
        var hasConnection = window.CheckForConnection();
        if (!hasConnection) {
            navigator.notification.alert("No internet connection. Please, provide connection and try again.");
        }

        window.files = [];
        window.everlive.data('CarDealer').get()
            .then(function (data) {
                data.result.forEach(function (file) {
                    $.ajax({
                        type: "GET",
                        url: 'http://api.everlive.com/v1/84Kc0v5WmmEQxXDe/Files/' + file.Pic,
                        //headers: { "Authorization" : "Bearer your-access-token-here" },
                        contentType: "application/json",
                    }).then(function (picData) {
                        files.push({
                            'brand': file.Brand,
                            'model': file.Model,
                            'fuelType': file.FuelType,
                            'year': file.Year,
                            'kilometers': file.Kilometers,
                            'price': file.Price,
                            'description': file.Description,
                            'name': file.Name,
                            'phoneNumber': file.PhoneNumber,
                            'id': file.Id,
                            'imageUrl': picData.Result.Uri
                        });
                    })
                        .then(function () {
                            $("#cars").kendoMobileListView({
                                dataSource: files,
                                template:
                                    "<div id=\"eachItem\">" +
                                        "<img src='#= data.imageUrl #'>" +
                                        "<div id=\"eachItemContainer\">" +
                                                "<div id=\"brand\">Brand: #= data.brand #</div>" +
                                                "<div id=\"model\">Model: #= data.model #</div>" +
                                                "<div id=\"kilometers\">Kilometers: #= data.kilometers #</div>" +
                                                "<div id=\"price\">Price: #= data.price #</div>" +
                                                "<div id=\"#= data.id #\"></div>" +
                                        "</div>" +
                                "</div>"
                            });
                        });
                });
            });
    }
}());