var app = app || {};
app.viewmodels = app.viewmodels || {};

(function (scope) {
    'use strict';
    scope.addAd = kendo.observable({
        brand: '',
        model: '',
        fuelType: '',
        year: '',
        kilometers: '',
        description: '',
        saveAd: function () {
            var self = this;
            var success = function (data) {
                window.everlive.Files.create({
                    Filename: Math.random().toString(36).substring(2, 15) + ".jpg",
                    ContentType: "image/jpeg",
                    base64: data
                },
                        function (picData) {
                            //window.files.push({
                            //    brand: self.get('brand'),
                            //    model: self.get('model'),
                            //    fuelType: self.get('fuelType'),
                            //    year: self.get('year'),
                            //    kilometers: self.get('kilometers'),
                            //    description: self.get('description')
                            //});

                            window.everlive.data('CarDealer').create({
                                'Brand': self.get('brand'),
                                'Model': self.get('model'),
                                'FuelType': self.get('fuelType'),
                                'Year': self.get('year'),
                                'Kilometers': self.get('kilometers'),
                                'Description': self.get('description'),
                                'Pic': picData.result.Id
                            },
                                function () {
                                    navigator.notification.alert("Your ad has been added successfully!");
                                }).then(function () { console.dir(app) })
                        }, error);
            };

            var error = function () {
                var hasConnection = checkForConnection();
                if (!hasConnection) {
                    navigator.notification.alert("No internet connection. Please, provide connection and try again.");
                }
                else {
                    navigator.notification.alert("Unfortunately we could not add the image");
                }
            };
            var config = {
                destinationType: Camera.DestinationType.DATA_URL,
                targetHeight: 120,
                targetWidth: 120
            };

            navigator.camera.getPicture(success, error, config);
        }
    });
}(app.viewmodels));